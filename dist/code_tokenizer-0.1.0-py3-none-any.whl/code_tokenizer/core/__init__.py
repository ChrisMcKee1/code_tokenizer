"""Core tokenizer functionality."""
