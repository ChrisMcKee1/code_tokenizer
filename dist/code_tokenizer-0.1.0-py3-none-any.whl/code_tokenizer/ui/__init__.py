"""UI components for progress and statistics display."""
