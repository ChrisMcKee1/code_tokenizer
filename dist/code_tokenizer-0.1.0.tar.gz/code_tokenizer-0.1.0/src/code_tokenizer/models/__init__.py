"""Model configuration and constants."""

from .model_config import TokenizerConfig

__all__ = ["TokenizerConfig"]
