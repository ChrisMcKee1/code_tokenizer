"""Utility functions for path handling and filtering."""
